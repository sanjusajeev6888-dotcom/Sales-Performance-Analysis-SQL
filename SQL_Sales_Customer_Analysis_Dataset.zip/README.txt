SQL SALES & CUSTOMER ANALYSIS PROJECT DATASET

Tables:
1. customers (CustomerID PK)
2. categories (CategoryID PK)
3. products (ProductID PK, CategoryID FK -> categories.CategoryID)
4. salespersons (SalespersonID PK)
5. orders (OrderID PK, CustomerID FK, ProductID FK, SalespersonID FK)

Date range: 2025-01-01 to 2025-12-31
Orders: 500

Main relationships:
customers.CustomerID -> orders.CustomerID
products.ProductID -> orders.ProductID
categories.CategoryID -> products.CategoryID
salespersons.SalespersonID -> orders.SalespersonID

Import all 5 CSV files into MySQL Workbench as separate tables.
